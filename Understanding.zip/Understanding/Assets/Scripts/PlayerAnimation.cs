﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimation : MonoBehaviour
{
    PlayerData data;
    PlayerMovement movement;

    Animator animator;
    //SpriteRenderer sprite;
	

	void Start ()
    {
		data = GetComponent<PlayerData>();
        movement = GetComponent<PlayerMovement>();
        animator = GetComponent<Animator>();
        //sprite = GetComponent<SpriteRenderer>();
    }
	
	
	void Update ()
    {
		if (data.state != data.previousState)
        {
            animator.SetInteger("state", (int)data.state);
            data.previousState = data.state;
        }
	}
}
