﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMovement : MonoBehaviour
{
    protected Rigidbody2D body;

    public Vector2 JumpForce = new Vector2(0, 15);

    public float MovementSpeed = 5;
    public bool isOnJumpableSurface = false;
    

    public virtual void Jump()
    {
        if (isOnJumpableSurface)
        {
            body.AddForce(JumpForce, ForceMode2D.Impulse);
        }
        
    }

    public virtual void EndJump ()
    {

    }

    protected virtual void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.contacts.Length > 0 && collision.gameObject.tag == "Jumpable")
        {
            ContactPoint2D contact = collision.contacts[0];
            
            if (Vector3.Dot(contact.normal, Vector3.up) > 0.5)
            {
                isOnJumpableSurface = true;
            }
            else
            {
                isOnJumpableSurface = false;
            }
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Jumpable")
        {
            isOnJumpableSurface = false;
        }
    }
}
