﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PlayerState
{
    Idle,     //0
    //WalkingL, //1
    WalkingR, //1
    Jump,     //2
    Falling,  //3
   // JumpLeft, //5
    JumpRight,//4
    //FallL,    //7
    FallR   //5
}

public class PlayerData : MonoBehaviour
{
    public PlayerState state = PlayerState.Idle;
    public PlayerState previousState;
	
	void Start ()
    {
		
	}
	
	
	void Update ()
    {
		
	}
}
