﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : CharacterMovement
{
    public float horizontal, vertical;
    

    Vector2 CustomVelocity;

    SpriteRenderer renderer; // mohamed 
    PlayerData data;
	
	void Start ()
    {
        body = GetComponent<Rigidbody2D>();
        data = GetComponent<PlayerData>();

        renderer = GetComponent<SpriteRenderer>();// mohamed 
	}
	
	
	void Update ()
    {
        horizontal = Input.GetAxis("Horizontal");
        vertical = Input.GetAxis("Vertical");

        CustomVelocity.x = horizontal * MovementSpeed;
        CustomVelocity.y = body.velocity.y;

        body.velocity = CustomVelocity;


        // mohamed 
        if(horizontal < 0)
        {
            renderer.flipX = true;
        }else if (horizontal >0)
        {
            renderer.flipX = false;
        }
        

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Jump();
        }


        // mohamed 
        if(isOnJumpableSurface && horizontal != 0)
        {
            data.state = PlayerState.WalkingR;
        }
        else if(body.velocity.y > 0)
        {
            if (horizontal != 0)
            {
                data.state = PlayerState.JumpRight;
            }
            else
            {
                data.state = PlayerState.Jump;
            }
        }
        else if(body.velocity.y <= 0 && !isOnJumpableSurface)
        {
            if (horizontal != 0)
            {
                data.state = PlayerState.FallR;
            }
            else
            {
                data.state = PlayerState.Falling;
            }
        }
        else
        {
            data.state = PlayerState.Idle;
        }

	}

    
}
